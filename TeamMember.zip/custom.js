$(document).ready(function() {
    // When a "Read More" button is clicked
    $(".column button").click(function() {
        // Find the parent column
        var column = $(this).closest(".column");
        var social_link = $

        // Get the title and image of the column
        var title = column.find("h2").text();
        var des = column.find("p").text();
        var imageSrc = column.find("img").attr("src");
        var socialLink = column.find(".social_link");


        // Create and display the popup
        var popup = $("<div class='popup'>"
            + "<div class='team'>"
            + "<img src='" + imageSrc + "' alt='Popup Image'>"
            + "<h2>" + title + "</h2>"
            + "<p>"+ des +"</p>"
            + '<div class="social_link">'
            + socialLink.html()
            + '</div>'
            + "<button class='close-popup'>Close</button>"
            + "</div>"
            + "</div>");

        $("body").append(popup);


        // Show the hidden elements in the popup
        popup.find(".social_link").show();

        // Close the popup when the "Close" button is clicked
        $(".close-popup").click(function() {
            popup.remove();
        });
    });
});

